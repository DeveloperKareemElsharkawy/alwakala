<?php

namespace App\Http\Controllers\Consumer;

use App\Http\Requests\Shared\LoginRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class ConsumersController extends Controller
{

}
