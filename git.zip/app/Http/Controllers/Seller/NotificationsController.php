<?php

namespace App\Http\Controllers\Seller;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class NotificationsController extends Controller
{
    public function index()
    {

    }

    public function markAllRead()
    {
    }

    public function markReadById(Request $request)
    {

    }

    public function unreadCount(Request $request)
    {
    }
}
