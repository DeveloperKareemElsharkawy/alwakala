<?php

namespace App\Enums\PaymentMethods;

class APaymentMethods
{
    const COD = 1;
    const VODAFONE_CASH = 2;

}
