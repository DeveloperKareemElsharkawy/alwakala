<?php


namespace App\Enums\Apps;


class AApps
{
    const SELLER_APP = 1;
    const CONSUMER_APP = 2;
}
