<?php
namespace App\Enums\Roles;

class ARoles
{
    const SUPER_USER = 'super_user';
    const ADMIN = 'admin';

    const OWNER = 'owner';
    const PURCHASE_MANGER = 'purchase_manger';
    const SALES_MANGER = 'sales_manger';
    const SALES = 'sales';
}
