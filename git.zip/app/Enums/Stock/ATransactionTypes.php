<?php


namespace App\Enums\Stock;


class ATransactionTypes
{
    const PRODUCT = 1;
    const PURCHASE_ORDER = 2;
    const INVENTORY = 3;
    const SALE = 4;
    const CANCEL_PURCHASE_ORDER = 5;
    const REJECT_PURCHASE_ORDER = 6;

}
