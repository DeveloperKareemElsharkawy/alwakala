<?php

namespace App\Enums\Activity;
class ActivityType
{
    const PRODUCT = 'product';
    const STORE = 'store';
    const ORDER = 'order';
}
