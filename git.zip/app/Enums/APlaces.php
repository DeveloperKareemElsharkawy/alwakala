<?php


namespace App\Enums;


class APlaces
{
    const COUNTRY = 1;
    const REGION = 2;
    const STATE = 3;
    const CITY = 4;
    const AREA = 5;
    const ZONE = 6;
}
