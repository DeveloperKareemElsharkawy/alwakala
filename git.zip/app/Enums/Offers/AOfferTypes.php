<?php


namespace App\Enums\Offers;


class AOfferTypes
{
    const SUPPLIER_TO_SELLER = 1;
    const SELLER_TO_CONSUMER = 2;
    const SUPPLIER_TO_CONSUMER = 3;
}
