<?php


namespace App\Enums\AChannels;


class AChannels
{
    const SELLER_APP = 'seller-app';
    const CONSUMER_APP = 'consumer-app';
    const ADMIN_DASHBOARD = 'admin-dashboard';
}
