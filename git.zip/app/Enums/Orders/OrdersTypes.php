<?php

namespace App\Enums\Orders;

class OrdersTypes
{
    const FROM_CONSUMER = 1;
    const FROM_SELLER = 2;
    const TO_SELLER = 3;
    const FROM_STORE = 4;

}
