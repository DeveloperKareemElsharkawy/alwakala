<?php

namespace App\Enums\Product;

class APolicyTypes
{
    const WekalaPrime = 1;
    const NonWekala = 2;

}
