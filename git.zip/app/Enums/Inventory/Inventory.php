<?php

namespace App\Enums\Inventory;

class Inventory
{
    const IN_STOCK = "In Stock";
    const OUT_STOCK = "Out Of Stock";
    const COMING_SOON = "Coming Soon";
}
