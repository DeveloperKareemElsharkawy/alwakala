<?php
namespace App\Enums\StoreTypes;
class StoreType
{
    const RETAILER = 1;
    const SUPPLIER = 2;
}
