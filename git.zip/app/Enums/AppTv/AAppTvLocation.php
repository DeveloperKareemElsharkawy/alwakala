<?php


namespace App\Enums\AppTv;


class AAppTvLocation
{
    const HOME = 'home';
    const STORE = 'store';
    const Category = 'category';
}
