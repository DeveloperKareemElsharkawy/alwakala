<?php


namespace App\Enums\AppTv;


class AAppTvTypes
{
    const PRODUCT = 1;
    const STORE = 2;
    const PAGE = 3;
}
