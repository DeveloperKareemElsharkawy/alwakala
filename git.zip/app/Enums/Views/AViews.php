<?php


namespace App\Enums\Views;


class AViews
{
    const PRODUCT = 'PRODUCT';
    const FEED = 'FEED';
    const STORE = 'STORE';
    const SHIPPING_COMPANY = 'SHIPPING_COMPANY';
}
