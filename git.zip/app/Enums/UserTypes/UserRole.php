<?php

namespace App\Enums\UserTypes;
class UserRole
{
    const SELLER_OWNER = 'owner';
    const SELLER_SUPER_ADMIN = 'super_user';
}
