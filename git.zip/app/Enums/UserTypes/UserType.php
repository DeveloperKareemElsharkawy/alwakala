<?php

namespace App\Enums\UserTypes;
class UserType
{
    const ADMIN = 1;
    const SELLER = 2;
    const CONSUMER = 3;

}
