<?php

namespace App\Enums\SizeTypes;

class ASizeTypes
{
    const NUMBERS = 'NUMBERS';
    const TEXT = 'TEXT';
}
